#include <stdio.h>
#include "CPUs.h"
#include "processQueue.h"

void* FCFScpu (void* param){
}

void* SJFcpu (void* param){
}

void* NPPcpu (void* param){
}

void* RRcpu (void* param){
}

void* SRTFcpu (void* param){
}

void* PPcpu (void* param){
}

